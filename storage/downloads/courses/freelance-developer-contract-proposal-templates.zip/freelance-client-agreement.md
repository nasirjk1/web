# INDEPENDENT CONTRACTOR SERVICE AGREEMENT

**Client:** [Client Name / Company]
**Developer:** [Your Name / Web Nasir Alumni]
**Effective Date:** [Date]

## 1. Scope of Work
The Developer agrees to architect, build, and deliver the software application specified in Schedule A.

## 2. Payment Terms
- 40% upfront deposit upon contract signing.
- 30% milestone payment upon staging demo approval.
- 30% final balance upon production deployment.

## 3. Intellectual Property
All intellectual property and code repository ownership transfers to the Client immediately upon receipt of final payment.
