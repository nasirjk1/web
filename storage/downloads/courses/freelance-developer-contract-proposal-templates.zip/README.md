# Freelance Developer Contracts & Proposal Templates
Web Nasir Academy — Official Resource

## Included Assets
1. freelance-client-agreement.md - Standard Independent Contractor Agreement with IP rights transfer upon final payment.
2. technical-project-proposal-template.md - High-win client proposal breakdown with milestone pricing.
3. invoice-template.html - Clean, printable HTML invoice template.
